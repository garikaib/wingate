<?php
/**
 * Course Layout Page (clickable map)
 *
 * @package Wingate
 */

get_header();
?>

<main class="wingate-course-layout">
	<section class="layout-hero">
		<div class="container">
			<p class="kicker">The Course</p>
			<h1>Course Layout</h1>
			<p class="subtitle">Interactive course map powered by OpenStreetMap. Click any hole on the map or list to inspect routing and details.</p>
		</div>
	</section>

	<section class="layout-shell container">
		<aside class="layout-panel">
			<div class="panel-head">
				<h2>Holes</h2>
				<span id="hole-total">18 total</span>
			</div>
			<div class="panel-search">
				<input id="hole-search" type="search" placeholder="Search hole number..." />
			</div>
			<ul id="hole-list" class="hole-list" aria-label="Course holes"></ul>
			<div class="panel-note">
				<strong>Note:</strong> Coordinates can be refined with GPS-surveyed tee/green points for pin-point accuracy.
			</div>
		</aside>

		<div class="layout-map-wrap">
			<div class="map-toolbar">
				<div>
					<h3>Wingate Park Golf Course</h3>
					<p>Center: -17.72073, 31.07663</p>
				</div>
				<div class="map-legend">
					<span><i class="legend tee"></i>Tee</span>
					<span><i class="legend green"></i>Green</span>
					<span><i class="legend fairway"></i>Hole Route</span>
				</div>
			</div>
			<div id="course-layout-map" class="layout-map" role="region" aria-label="Course layout map"></div>
		</div>
	</section>
</main>

<style>
.wingate-course-layout {
	background: radial-gradient(1200px 600px at 10% -20%, rgba(255, 204, 0, 0.25), transparent), #f3f5f8;
	color: #0e1b3d;
	min-height: 100vh;
	padding-bottom: 40px;
}
.wingate-course-layout .container {
	max-width: 1240px;
	margin: 0 auto;
	padding: 0 16px;
}
.wingate-course-layout .layout-hero {
	padding: 34px 0 18px;
}
.wingate-course-layout .kicker {
	margin: 0;
	font-size: 11px;
	font-weight: 700;
	letter-spacing: 0.16em;
	text-transform: uppercase;
	color: #7a88a2;
}
.wingate-course-layout h1 {
	margin: 6px 0 10px;
	font-family: "Cinzel", serif;
	font-size: clamp(32px, 4vw, 52px);
	line-height: 1;
}
.wingate-course-layout .subtitle {
	margin: 0;
	max-width: 760px;
	font-size: 16px;
	color: #475777;
}
.wingate-course-layout .layout-shell {
	display: grid;
	grid-template-columns: 320px minmax(0, 1fr);
	gap: 18px;
	align-items: start;
}
.wingate-course-layout .layout-panel,
.wingate-course-layout .layout-map-wrap {
	background: #fff;
	border: 1px solid rgba(14, 27, 61, 0.1);
	border-radius: 20px;
	box-shadow: 0 20px 50px -40px rgba(14, 27, 61, 0.55);
}
.wingate-course-layout .layout-panel {
	padding: 16px;
}
.wingate-course-layout .panel-head {
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin-bottom: 12px;
}
.wingate-course-layout .panel-head h2 {
	margin: 0;
	font-family: "Cinzel", serif;
	font-size: 22px;
}
.wingate-course-layout .panel-head span {
	font-size: 10px;
	font-weight: 700;
	letter-spacing: 0.16em;
	text-transform: uppercase;
	color: #7a88a2;
}
.wingate-course-layout .panel-search input {
	width: 100%;
	border: 1px solid rgba(14, 27, 61, 0.15);
	border-radius: 10px;
	padding: 10px 12px;
	font-size: 14px;
	outline: none;
	margin-bottom: 10px;
}
.wingate-course-layout .panel-search input:focus {
	border-color: #0e1b3d;
	box-shadow: 0 0 0 2px rgba(14, 27, 61, 0.12);
}
.wingate-course-layout .hole-list {
	list-style: none;
	margin: 0;
	padding: 0;
	max-height: 600px;
	overflow: auto;
	display: grid;
	gap: 8px;
}
.wingate-course-layout .hole-row {
	width: 100%;
	text-align: left;
	border: 1px solid rgba(14, 27, 61, 0.12);
	border-radius: 12px;
	background: #f9fafc;
	padding: 10px 11px;
	display: grid;
	grid-template-columns: auto 1fr auto;
	gap: 8px;
	align-items: center;
	cursor: pointer;
	transition: all .2s ease;
}
.wingate-course-layout .hole-row:hover {
	border-color: #0e1b3d;
	background: rgba(14, 27, 61, 0.04);
}
.wingate-course-layout .hole-row.active {
	background: #0e1b3d;
	border-color: #0e1b3d;
	color: #fff;
}
.wingate-course-layout .hole-badge {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	width: 28px;
	height: 28px;
	border-radius: 999px;
	background: #ffcc00;
	color: #0e1b3d;
	font-size: 12px;
	font-weight: 700;
}
.wingate-course-layout .hole-meta strong {
	display: block;
	font-size: 13px;
}
.wingate-course-layout .hole-meta span {
	display: block;
	font-size: 11px;
	opacity: .8;
}
.wingate-course-layout .hole-dist {
	font-size: 11px;
	font-weight: 700;
	letter-spacing: 0.08em;
	text-transform: uppercase;
}
.wingate-course-layout .panel-note {
	margin-top: 10px;
	border: 1px dashed rgba(14, 27, 61, 0.18);
	background: rgba(255, 204, 0, 0.12);
	padding: 10px 11px;
	border-radius: 10px;
	font-size: 12px;
	color: #3d4d6f;
}
.wingate-course-layout .layout-map-wrap {
	padding: 12px;
}
.wingate-course-layout .map-toolbar {
	display: flex;
	flex-wrap: wrap;
	gap: 8px 20px;
	justify-content: space-between;
	align-items: center;
	margin-bottom: 8px;
	padding: 4px 4px 8px;
}
.wingate-course-layout .map-toolbar h3 {
	margin: 0;
	font-family: "Cinzel", serif;
	font-size: 24px;
}
.wingate-course-layout .map-toolbar p {
	margin: 2px 0 0;
	font-size: 12px;
	color: #657596;
}
.wingate-course-layout .map-legend {
	display: flex;
	flex-wrap: wrap;
	gap: 10px;
	font-size: 10px;
	font-weight: 700;
	letter-spacing: 0.12em;
	text-transform: uppercase;
	color: #657596;
}
.wingate-course-layout .map-legend span {
	display: inline-flex;
	align-items: center;
	gap: 6px;
}
.wingate-course-layout .legend {
	width: 10px;
	height: 10px;
	border-radius: 999px;
	display: inline-block;
}
.wingate-course-layout .legend.tee { background: #0e1b3d; }
.wingate-course-layout .legend.green { background: #2b8a3e; }
.wingate-course-layout .legend.fairway { background: #ff7a00; }
.wingate-course-layout .layout-map {
	height: 72vh;
	min-height: 520px;
	border-radius: 14px;
	overflow: hidden;
	border: 1px solid rgba(14, 27, 61, 0.12);
}
.wingate-hole-popup h4 {
	margin: 0 0 4px;
	font-family: "Cinzel", serif;
	font-size: 18px;
}
.wingate-hole-popup p {
	margin: 0;
	font-size: 13px;
}
.wingate-course-layout .hole-chip {
	background: rgba(14, 27, 61, 0.9);
	border: 1px solid rgba(255, 255, 255, 0.85);
	border-radius: 999px;
	box-shadow: 0 10px 20px -14px rgba(14, 27, 61, 0.95);
	color: #fff;
	font-size: 11px;
	font-weight: 700;
	letter-spacing: 0.08em;
	padding: 4px 8px;
	text-transform: uppercase;
	white-space: nowrap;
}
.wingate-course-layout .hole-chip.hole-chip-green {
	background: rgba(43, 138, 62, 0.92);
}
.wingate-course-layout .hole-chip.hole-chip-hole {
	background: rgba(255, 204, 0, 0.95);
	color: #0e1b3d;
}
@media (max-width: 1000px) {
	.wingate-course-layout .layout-shell {
		grid-template-columns: 1fr;
	}
	.wingate-course-layout .hole-list {
		max-height: 300px;
	}
	.wingate-course-layout .layout-map {
		height: 64vh;
		min-height: 420px;
	}
}
</style>

<link
	rel="stylesheet"
	href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
	integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
	crossorigin=""
/>
<script
	src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
	integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
	crossorigin=""
	defer
></script>
<script>
<?php
// Inject dynamic hole data from admin
$admin_settings = get_option('wingate_hole_by_hole_settings', []);
$admin_holes = isset($admin_settings['holes']) ? $admin_settings['holes'] : [];
$dynamic_paths = [];
foreach ($admin_holes as $hole_data) {
    if (!empty($hole_data['path']) && is_array($hole_data['path'])) {
        $dynamic_paths[$hole_data['hole']] = $hole_data['path'];
    }
}
echo 'const dynamicPaths = ' . wp_json_encode($dynamic_paths) . ';';

$can_edit = current_user_can('manage_options') ? 'true' : 'false';
echo "const canEditHoles = {$can_edit};";
?>

document.addEventListener('DOMContentLoaded', function () {
	const mapRoot = document.getElementById('course-layout-map');
	const listRoot = document.getElementById('hole-list');
	const searchRoot = document.getElementById('hole-search');
	if (!mapRoot || !listRoot || !window.L) return;

	const center = [-17.72073, 31.07663];
	const map = L.map(mapRoot, {
		zoomControl: true,
		scrollWheelZoom: true,
		maxZoom: 19,
		minZoom: 14,
	}).setView(center, 17);

	const streetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
		maxZoom: 19,
		attribution: '&copy; OpenStreetMap contributors',
	});
	const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
		maxZoom: 19,
		attribution: 'Tiles &copy; Esri',
	});
	satelliteLayer.addTo(map);
	L.control.layers(
		{
			Street: streetLayer,
			Satellite: satelliteLayer,
		},
		{},
		{ position: 'topright', collapsed: false }
	).addTo(map);

	const holes = [
		{
			n: 1,
			par: 4,
			m: 365,
			tee: [-17.72016, 31.07537],
			green: [-17.71892, 31.07543],
			path: [
				[-17.72016, 31.07537],
				[-17.71978, 31.07536],
				[-17.71934, 31.07539],
				[-17.71892, 31.07543],
			],
			label: [-17.71956, 31.07548],
			teeLabel: [-17.72012, 31.0755],
			greenLabel: [-17.7189, 31.07556],
		},
		{
			n: 2,
			par: 3,
			m: 175,
			tee: [-17.72142, 31.07702],
			green: [-17.71992, 31.07685],
			path: [
				[-17.72142, 31.07702],
				[-17.7208, 31.07695],
				[-17.7204, 31.07690],
				[-17.71992, 31.07685],
			],
		},
		{
			n: 3,
			par: 5,
			m: 505,
			tee: [-17.72185, 31.07820],
			green: [-17.72140, 31.07590],
			path: [
				[-17.72185, 31.07820],
				[-17.72195, 31.07780],
				[-17.72200, 31.07730],
				[-17.72190, 31.07680],
				[-17.72170, 31.07640],
				[-17.72140, 31.07590],
			],
		},
		{
			n: 4,
			par: 4,
			m: 390,
			tee: [-17.71880, 31.07680],
			green: [-17.71940, 31.07720],
			path: [
				[-17.71880, 31.07680],
				[-17.71895, 31.07690],
				[-17.71915, 31.07705],
				[-17.71940, 31.07720],
			],
		},
		{
			n: 5,
			par: 4,
			m: 375,
			tee: [-17.71950, 31.07750],
			green: [-17.72060, 31.07740],
			path: [
				[-17.71950, 31.07750],
				[-17.71980, 31.07748],
				[-17.72020, 31.07744],
				[-17.72060, 31.07740],
			],
		},
		{
			n: 6,
			par: 4,
			m: 360,
			tee: [-17.72280, 31.07550],
			green: [-17.72190, 31.07530],
			path: [
				[-17.72280, 31.07550],
				[-17.72255, 31.07542],
				[-17.72220, 31.07535],
				[-17.72190, 31.07530],
			],
		},
		{
			n: 7,
			par: 3,
			m: 160,
			tee: [-17.72240, 31.07480],
			green: [-17.72190, 31.07460],
			path: [
				[-17.72240, 31.07480],
				[-17.72218, 31.07472],
				[-17.72190, 31.07460],
			],
		},
		{
			n: 8,
			par: 5,
			m: 520,
			tee: [-17.72220, 31.07420],
			green: [-17.72100, 31.07400],
			path: [
				[-17.72220, 31.07420],
				[-17.72195, 31.07415],
				[-17.72165, 31.07410],
				[-17.72135, 31.07405],
				[-17.72100, 31.07400],
			],
		},
		{
			n: 9,
			par: 4,
			m: 385,
			tee: [-17.72012, 31.07474],
			green: [-17.71898, 31.07486],
			path: [
				[-17.72012, 31.07474],
				[-17.71972, 31.07474],
				[-17.7193, 31.07478],
				[-17.71898, 31.07486],
			],
			label: [-17.7195, 31.07489],
			teeLabel: [-17.7201, 31.07487],
			greenLabel: [-17.71895, 31.07498],
		},
		{ n: 10, par: 4, y: 0.0019, x: 0.0007, dy: 0.00085, dx: 0.00015, m: 370 },
		{ n: 11, par: 3, y: 0.0019, x: 0.0013, dy: 0.00055, dx: 0.00025, m: 185 },
		{ n: 12, par: 4, y: 0.0012, x: 0.0018, dy: -0.00095, dx: 0.0002, m: 380 },
		{ n: 13, par: 4, y: 0.0002, x: 0.0019, dy: -0.0009, dx: -0.0002, m: 350 },
		{ n: 14, par: 5, y: -0.0008, x: 0.0014, dy: -0.00115, dx: -0.00045, m: 535 },
		{ n: 15, par: 4, y: -0.0004, x: 0.0008, dy: -0.0009, dx: 0.0002, m: 400 },
		{ n: 16, par: 4, y: -0.0011, x: 0.0004, dy: -0.0008, dx: 0.0004, m: 395 },
		{ n: 17, par: 4, y: -0.0001, x: -0.0002, dy: -0.0010, dx: -0.00025, m: 365 },
		{
			n: 18,
			par: 4,
			m: 410,
			tee: [-17.7201, 31.07596],
			green: [-17.71897, 31.0759],
			path: [
				[-17.7201, 31.07596],
				[-17.71972, 31.07595],
				[-17.71934, 31.07592],
				[-17.71897, 31.0759],
			],
			label: [-17.71953, 31.07602],
			teeLabel: [-17.72008, 31.07609],
			greenLabel: [-17.71895, 31.07602],
		},
	].map((hole) => {
		// Use dynamic path from admin if available
		const hasDynamicPath = dynamicPaths[hole.n] && dynamicPaths[hole.n].length >= 2;
		
		if (hasDynamicPath || (Array.isArray(hole.tee) && Array.isArray(hole.green))) {
			
			const customPath = hasDynamicPath ? dynamicPaths[hole.n] : hole.path;
			const customTee = hasDynamicPath ? dynamicPaths[hole.n][0] : hole.tee;
			const customGreen = hasDynamicPath ? dynamicPaths[hole.n][dynamicPaths[hole.n].length - 1] : hole.green;
			
			return {
				...hole,
				tee: customTee,
				green: customGreen,
				path: Array.isArray(customPath) && customPath.length >= 2 ? customPath : [customTee, customGreen],
				label: Array.isArray(hole.label) && !hasDynamicPath ? hole.label : [
					(customTee[0] + customGreen[0]) / 2,
					(customTee[1] + customGreen[1]) / 2,
				],
				teeLabel: Array.isArray(hole.teeLabel) && !hasDynamicPath ? hole.teeLabel : [customTee[0], customTee[1] + 0.00008],
				greenLabel: Array.isArray(hole.greenLabel) && !hasDynamicPath ? hole.greenLabel : [customGreen[0], customGreen[1] + 0.00008],
			};
		}

		const tee = [center[0] + hole.y, center[1] + hole.x];
		const green = [tee[0] + hole.dy, tee[1] + hole.dx];
		const midA = [tee[0] + (hole.dy * 0.33) + (hole.n % 2 ? 0.00011 : -0.0001), tee[1] + (hole.dx * 0.33)];
		const midB = [tee[0] + (hole.dy * 0.67), tee[1] + (hole.dx * 0.67) + (hole.n % 2 ? -0.00009 : 0.00011)];

		return {
			...hole,
			tee: tee,
			green: green,
			path: [tee, midA, midB, green],
			label: [
				(tee[0] + green[0]) / 2,
				(tee[1] + green[1]) / 2,
			],
			teeLabel: [tee[0], tee[1] + 0.00008],
			greenLabel: [green[0], green[1] + 0.00008],
		};
	});

	const layers = new Map();
	let activeHole = null;

	function createChip(position, text, className) {
		return L.marker(position, {
			interactive: false,
			icon: L.divIcon({
				className: '',
				html: `<span class="hole-chip ${className}">${text}</span>`,
				iconSize: null,
			}),
		});
	}

	function setActive(holeNumber) {
		activeHole = holeNumber;
		document.querySelectorAll('.hole-row').forEach((btn) => {
			btn.classList.toggle('active', Number(btn.dataset.hole) === holeNumber);
		});
		layers.forEach((layer, n) => {
			layer.route.setStyle({
				color: n === holeNumber ? '#ffcc00' : '#ff7a00',
				weight: n === holeNumber ? 5 : 3,
				opacity: n === holeNumber ? 1 : 0.85,
			});
		});
		layers.forEach((entry, n) => {
			[entry.holeLabel, entry.teeLabel, entry.greenLabel].forEach((labelLayer) => {
				if (!labelLayer) {
					return;
				}
				if (n === holeNumber) {
					if (!map.hasLayer(labelLayer)) {
						labelLayer.addTo(map);
					}
				} else if (map.hasLayer(labelLayer)) {
					map.removeLayer(labelLayer);
				}
			});
		});
		const layer = layers.get(holeNumber);
		if (layer) {
			map.flyTo(layer.tee.getLatLng(), 18, { duration: 0.45 });
			map.fitBounds(layer.route.getBounds(), { padding: [60, 60], maxZoom: 18 });
			layer.tee.openPopup();
		}
	}

	holes.forEach((h) => {
		const route = L.polyline(h.path, {
			color: '#ff7a00',
			weight: 3,
			opacity: 0.85,
		}).addTo(map);

		const teeMarker = L.circleMarker(h.tee, {
			radius: 5,
			weight: 2,
			color: '#ffffff',
			fillColor: '#0e1b3d',
			fillOpacity: 1,
		}).addTo(map);

		const greenMarker = L.circleMarker(h.green, {
			radius: 6,
			weight: 2,
			color: '#ffffff',
			fillColor: '#2b8a3e',
			fillOpacity: 1,
		}).addTo(map);

		const holeLabel = createChip(h.label, `Hole ${h.n}`, 'hole-chip-hole');
		const teeLabel = createChip(h.teeLabel, 'Tee', '');
		const greenLabel = createChip(h.greenLabel, 'Green', 'hole-chip-green');

		let popupHtml = `<div class="wingate-hole-popup"><h4>Hole ${h.n}</h4><p>Par ${h.par} · ${h.m}m</p>`;
		if (canEditHoles) {
			popupHtml += `<a href="/wp-admin/admin.php?page=wingate-hole-by-hole&hole=${h.n}" class="edit-hole-btn" target="_blank" style="display:inline-block; margin-top:8px; font-size:11px; font-weight:bold; color:#0e1b3d; text-decoration:underline;">✏️ Edit Route</a>`;
		}
		popupHtml += `</div>`;
		
		teeMarker.bindPopup(popupHtml);
		greenMarker.bindPopup(popupHtml);
		teeMarker.on('click', () => setActive(h.n));
		greenMarker.on('click', () => setActive(h.n));
		route.on('click', () => setActive(h.n));

		layers.set(h.n, {
			route: route,
			tee: teeMarker,
			green: greenMarker,
			holeLabel: holeLabel,
			teeLabel: teeLabel,
			greenLabel: greenLabel,
			data: h,
		});
	});

	function renderList(filter) {
		listRoot.innerHTML = '';
		const text = String(filter || '').trim();
		holes
			.filter((h) => !text || String(h.n).includes(text))
			.forEach((h) => {
				const li = document.createElement('li');
				const btn = document.createElement('button');
				btn.type = 'button';
				btn.className = 'hole-row';
				btn.dataset.hole = String(h.n);
				btn.innerHTML = `
					<span class="hole-badge">${h.n}</span>
					<span class="hole-meta"><strong>Hole ${h.n}</strong><span>Par ${h.par}</span></span>
					<span class="hole-dist">${h.m}m</span>
				`;
				btn.addEventListener('click', () => setActive(h.n));
				li.appendChild(btn);
				listRoot.appendChild(li);
			});
		if (activeHole) setActive(activeHole);
	}

	renderList('');
	searchRoot.addEventListener('input', (e) => renderList(e.target.value));
	setActive(1);
});
</script>

<?php
get_footer();
